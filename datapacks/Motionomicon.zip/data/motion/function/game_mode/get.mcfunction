execute if entity @s[gamemode=adventure] run return run data modify storage motion:data game_mode set value "adventure"
execute if entity @s[gamemode=survival] run return run data modify storage motion:data game_mode set value "survival"
data modify storage motion:data game_mode set value "creative"