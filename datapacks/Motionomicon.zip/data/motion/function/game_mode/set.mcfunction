$gamemode $(game_mode)
