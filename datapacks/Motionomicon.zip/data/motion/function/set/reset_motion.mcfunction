teleport 0 0 0
teleport ~ ~ ~
